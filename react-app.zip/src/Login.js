import React from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { AuthContext } from "./AuthContext";
import { Container, Row, Col, Form } from "react-bootstrap";

export const Login = () => {
  const [formData, setData] = React.useState({
    username: "",
    password: "",
  });

  let { username, password } = formData;

  const { auth, setAuth } = React.useContext(AuthContext);

  const navigate = useNavigate();
  // console.log(auth);

  async function fetchData(props) {
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: username,
        password: password,
      }),
    };
    await fetch("http://localhost:3340/api/Token", requestOptions)
      .then((res) => res.json())
      .then((response) => {
        console.log(response);
        localStorage.setItem("access", response.data);
        // sessionStorage.setItem("access", response.data);
        localStorage.setItem("isLoggedIn", true);
        setAuth({ isLoggedIn: true });
        console.log(auth);
        if (localStorage.getItem("isLoggedIn")==="true") {
          navigate("/");
        }
      })
      .catch((err) => console.log(err));
  }

  const handelSubmit = (e) => {
    e.preventDefault();

    fetchData();
  };

  if (localStorage.getItem("isLoggedIn") === "true") {
    console.log(localStorage.getItem("isLoggedIn"));
    return <Navigate to="/" />;
  }

  return (
    <React.Fragment>
      <main className="mt-3">
        <Container>
          <Row>
            <Col md={4}>
              <Form onSubmit={(e) => handelSubmit(e)}>
                <Form.Group className="mb-3">
                  <Form.Label htmlFor="username">Username</Form.Label>
                  <Form.Control
                    type={"text"}
                    name="username"
                    id="username"
                    value={username}
                    onChange={(e) =>
                      setData({ ...formData, [e.target.name]: e.target.value })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label htmlFor="password">Password</Form.Label>
                  <Form.Control
                    type={"password"}
                    name="password"
                    id="password"
                    value={password}
                    onChange={(e) =>
                      setData({ ...formData, [e.target.name]: e.target.value })
                    }
                  />
                </Form.Group>

                <Form.Group>
                  <Form.Control type={"submit"} value="Submit" className="btn btn-primary" />
                </Form.Group>
              </Form>
            </Col>
          </Row>
        </Container>
      </main>
    </React.Fragment>
  );
};
