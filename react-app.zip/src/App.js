import React from "react";
import { Login } from "./Login";
import { AuthProvider } from "./AuthContext";
import { Route, Routes } from "react-router-dom";
import { Homepage } from "./pages/Homepage";
import { AuditRequest } from "./pages/AuditRequest";
import { NavbarPage } from "./components/Navbar";
import { AuditRequestProvider } from "./AuditRequestContext";
import { AuditResponse } from "./pages/AuditResponse";



function App() {
  return (
    <AuthProvider>
      <AuditRequestProvider>
        <div className="App">
          <NavbarPage />
          <Routes>
            <Route path="/" element={<Homepage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/auditRequest" element={<AuditRequest />} />
            <Route path="/auditResponse" element={<AuditResponse />} />
          </Routes>
        </div>
      </AuditRequestProvider>
    </AuthProvider>
  );
}

export default App;
