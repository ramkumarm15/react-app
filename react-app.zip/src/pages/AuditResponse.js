import React from "react";

import { Container, Row, Col, Table } from "react-bootstrap";

import { AuditRequestContext } from "../AuditRequestContext";

export const AuditResponse = () => {
  const { auditResponse } = React.useContext(AuditRequestContext);

  const { data } = auditResponse;

  const classNameForTable =
    data.projectExexutionStatus === "RED" ? "redRow" : "greenRow";

  return (
    <>
      <main>
        <Container>
          <Row>
            <Col md={12}>
              <div className="mt-5 p-5 bg-light">
                <div className="text-center">
                  <h1>Audit Response</h1>
                  <Table striped bordered hover size="sm">
                    <thead>
                      <tr>
                        <th>Audit ID</th>
                        <th>Project Exexution Status</th>
                        <th>Remedial Action Duration</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className={classNameForTable}>
                        <td>{data.auditId}</td>
                        <td>{data.projectExexutionStatus}</td>
                        <td>{data.remedialActionDuration}</td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </main>
    </>
  );
};
