import React from "react";
import { AuthContext } from "../AuthContext";
import { Link, Navigate } from "react-router-dom";

export const Homepage = () => {
  const { auth } = React.useContext(AuthContext);

  if (localStorage.getItem("isLoggedIn") === "false") {
    return <Navigate to="/login" />;
  }

  return (
    <React.Fragment>
      <React.Fragment>
        <Link to="/auditRequest">Request</Link>
      </React.Fragment>
    </React.Fragment>
  );
};
