import axios from "axios";
import React from "react";
import { Link } from "react-router-dom";
import { Button, Form, Container, Row, Col } from "react-bootstrap";
import { Navigate, useNavigate } from "react-router-dom";
import { AuditRequestContext } from "../AuditRequestContext";
import { Questions } from "../components/Questions";

// axios.defaults.headers.common["Authorization"] = }`;

const config = {
  headers: {
    Authorization: `Bearer ${localStorage.getItem("access")}`,
  },
};

export const AuditRequest = () => {
  const {
    show,
    setShow,
    checkList,
    setCheckList,
    auditDetails,
    setAuditDetails,
    projectDetails,
    setProjectDetails,
    questions,
    auditResponse,
    setAuditResponse,
  } = React.useContext(AuditRequestContext);

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { data } = await axios.get(
        `http://localhost:39583/api/AuditChecklist/${auditDetails.type}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access")}`,
          },
        }
      );
      // console.log(response);
      setCheckList({ data });
      setShow(true);
    } catch (err) {
      console.log(err);
      if (err.response.status === 401) {
        localStorage.removeItem("access");
        localStorage.setItem("isLoggedIn", false);
        navigate("/login");
      }
    }
  };

  const handleSubmitRequest = async (e) => {
    e.preventDefault();

    const formData = {
      projectName: projectDetails.projectName,
      projectManagerName: projectDetails.projectManagerName,
      applicationOwnerName: projectDetails.applicationOwnerName,
      auditDetails: {
        type: auditDetails.type,
        date: auditDetails.date,
        questions,
      },
    };

    const body = JSON.stringify(formData);

    const res = await axios.post(
      "https://localhost:44303/api/AuditSeverity",
      body,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    if (res.status === 200) {
      setAuditResponse(() => ({ data: res.data, generated: true }));
      navigate("/auditResponse");
    }
  };

  return (
    <React.Fragment>
      {localStorage.getItem("isLoggedIn") === "true" ? (
        <main className="mt-3">
          <Container>
            <Row>
              <Col md={4}>
                <Form onSubmit={(e) => handleSubmit(e)}>
                  <Form.Group className="mb-3">
                    <Form.Check
                      type="radio"
                      label="Internal"
                      name="internal"
                      value="Internal"
                      checked={auditDetails.type === "Internal"}
                      onChange={(e) =>
                        setAuditDetails((prevState) => ({
                          ...prevState,
                          type: e.target.value,
                        }))
                      }
                    />
                    <Form.Check
                      type="radio"
                      label="SOX"
                      name="SOX"
                      value="SOX"
                      checked={auditDetails.type === "SOX"}
                      onChange={(e) =>
                        setAuditDetails({ type: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Control
                      type="date"
                      value={checkList.date}
                      onChange={(e) =>
                        setAuditDetails((prevState) => ({
                          ...prevState,
                          date: e.target.value,
                        }))
                      }
                      required
                    />
                  </Form.Group>
                  <Button type="submit">Proceed</Button>
                </Form>
              </Col>
            </Row>

            {show ? (
              <>
                <Form onSubmit={(e) => handleSubmitRequest(e)}>
                  <Row className="mt-4">
                    <Col md={5}>
                      <Form.Group className="mb-3">
                        <Form.Label>Project Name</Form.Label>
                        <Form.Control
                          type="text"
                          name="projectName"
                          value={projectDetails.projectName}
                          placeholder="Audit Management System"
                          onChange={(e) =>
                            setProjectDetails((prevState) => ({
                              ...prevState,
                              [e.target.name]: e.target.value,
                            }))
                          }
                          required
                        />
                      </Form.Group>
                      <Form.Group className="mb-3">
                        <Form.Label>Project Manager Name</Form.Label>
                        <Form.Control
                          type="text"
                          name="projectManagerName"
                          placeholder="Ramkumar"
                          value={projectDetails.projectManagerName}
                          onChange={(e) =>
                            setProjectDetails((prevState) => ({
                              ...prevState,
                              [e.target.name]: e.target.value,
                            }))
                          }
                          required
                        />
                      </Form.Group>
                      <Form.Group className="mb-3">
                        <Form.Label>Application Owner Name</Form.Label>
                        <Form.Control
                          type="text"
                          name="applicationOwnerName"
                          value={projectDetails.applicationOwnerName}
                          placeholder="Sowndharya"
                          onChange={(e) =>
                            setProjectDetails((prevState) => ({
                              ...prevState,
                              [e.target.name]: e.target.value,
                            }))
                          }
                          required
                        />
                      </Form.Group>
                      <Form.Group className="mb-3">
                        <Button type="submit">Submit</Button>
                      </Form.Group>
                    </Col>
                    <Col md={6} className="offset-md-1">
                      <Questions checkLists={checkList.data} />
                    </Col>
                  </Row>
                </Form>
              </>
            ) : (
              ""
            )}
            {auditResponse.generated ? (
              <>
                <Row className="mt-3">
                  <Col md={12}>
                    <h5>Response Generated</h5>
                    <Link to="/auditResponse" className="btn btn-success">
                      Click to see
                    </Link>
                  </Col>
                </Row>
              </>
            ) : (
              ""
            )}
          </Container>
        </main>
      ) : (
        <Navigate to="/login" />
      )}
    </React.Fragment>
  );
};
